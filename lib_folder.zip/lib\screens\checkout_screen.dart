// lib/screens/checkout_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:dcs_app/utils/app_colors.dart';
import 'package:dcs_app/utils/responsive.dart';
import 'package:dcs_app/providers/cart_provider.dart';
import 'package:dcs_app/providers/order_provider.dart';
import 'package:dcs_app/services/order_service.dart';

class CheckoutScreen extends ConsumerStatefulWidget {
  const CheckoutScreen({super.key});

  @override
  ConsumerState<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends ConsumerState<CheckoutScreen> {
  final _formKey       = GlobalKey<FormState>();
  final _addressCtrl   = TextEditingController();
  final _cityCtrl      = TextEditingController();
  final _stateCtrl     = TextEditingController();
  final _dateCtrl      = TextEditingController();
  final _timeCtrl      = TextEditingController();

  String _selectedPayment = 'cod';
  bool   _isPlacingOrder  = false;

  final OrderService _orderService = OrderService();

  @override
  void dispose() {
    _addressCtrl.dispose();
    _cityCtrl.dispose();
    _stateCtrl.dispose();
    _dateCtrl.dispose();
    _timeCtrl.dispose();
    super.dispose();
  }

  Future<void> _placeOrder() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isPlacingOrder = true);

    try {
      bool success = false;

      if (_selectedPayment == 'online') {
        success = await ref.read(orderProvider.notifier).processAdvanceOrder(
          address: _addressCtrl.text.trim(),
          city:    _cityCtrl.text.trim(),
          state_:  _stateCtrl.text.trim(),
          date:    _dateCtrl.text.trim(),
          time:    _timeCtrl.text.trim(),
        );
      } else {
        success = await ref.read(orderProvider.notifier).processOrder(
          address: _addressCtrl.text.trim(),
          city:    _cityCtrl.text.trim(),
          state_:  _stateCtrl.text.trim(),
          date:    _dateCtrl.text.trim(),
          time:    _timeCtrl.text.trim(),
        );
      }

      if (success) {
        ref.read(cartProvider.notifier).clearCart();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Order placed successfully!'),
              backgroundColor: AppColors.green,
            ),
          );
          context.go('/orders');
        }
      } else {
        final error = ref.read(orderProvider).error ?? 'Order failed';
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(error),
              backgroundColor: AppColors.secondary,
            ),
          );
        }
      }
    } finally {
      if (mounted) setState(() => _isPlacingOrder = false);
    }
  }

  Future<void> _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 1)),
      firstDate:   DateTime.now(),
      lastDate:    DateTime.now().add(const Duration(days: 30)),
    );
    if (picked != null) {
      _dateCtrl.text =
      '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
    }
  }

  Future<void> _selectTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 10, minute: 0),
    );
    if (picked != null) {
      _timeCtrl.text =
      '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
    }
  }

  @override
  Widget build(BuildContext context) {
    final cartState = ref.watch(cartProvider);

    if (cartState.cartItems.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Checkout', style: TextStyle(fontWeight: FontWeight.w700)),
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
        ),
        body: const Center(child: Text('Your cart is empty')),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: const Text('Checkout', style: TextStyle(fontWeight: FontWeight.w700)),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              // ── Service Location ───────────────
              const Text(
                'Service Location',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.black),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _addressCtrl,
                maxLines: 2,
                validator: (v) => v!.isEmpty ? 'Address required' : null,
                decoration: const InputDecoration(
                  hintText: 'Enter full address',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _cityCtrl,
                validator: (v) => v!.isEmpty ? 'City required' : null,
                decoration: const InputDecoration(
                  hintText: 'City',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _stateCtrl,
                validator: (v) => v!.isEmpty ? 'State required' : null,
                decoration: const InputDecoration(
                  hintText: 'State',
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 20),

              // ── Schedule Service ───────────────
              const Text(
                'Schedule Service',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.black),
              ),
              const SizedBox(height: 12),
              GestureDetector(
                onTap: _selectDate,
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: _dateCtrl,
                    validator: (v) => v!.isEmpty ? 'Date required' : null,
                    decoration: const InputDecoration(
                      hintText: 'Select date',
                      border: OutlineInputBorder(),
                      suffixIcon: Icon(Icons.calendar_today),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              GestureDetector(
                onTap: _selectTime,
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: _timeCtrl,
                    validator: (v) => v!.isEmpty ? 'Time required' : null,
                    decoration: const InputDecoration(
                      hintText: 'Select time',
                      border: OutlineInputBorder(),
                      suffixIcon: Icon(Icons.access_time),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // ── Payment Method ─────────────────
              const Text(
                'Payment Method',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.black),
              ),
              const SizedBox(height: 12),
              _PaymentOption(
                label:      'Cash on Delivery',
                value:      'cod',
                groupValue: _selectedPayment,
                onChanged:  (v) => setState(() => _selectedPayment = v!),
              ),
              _PaymentOption(
                label:      'Online Payment (Razorpay)',
                value:      'online',
                groupValue: _selectedPayment,
                onChanged:  (v) => setState(() => _selectedPayment = v!),
              ),

              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
      bottomSheet: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.white,
          border: const Border(top: BorderSide(color: AppColors.border)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Total Amount', style: TextStyle(color: AppColors.textMuted)),
                Text(
                  '₹${cartState.finalAmount.toStringAsFixed(0)}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isPlacingOrder ? null : _placeOrder,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: _isPlacingOrder
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('Place Order', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PaymentOption extends StatelessWidget {
  final String label, value, groupValue;
  final Function(String?) onChanged;

  const _PaymentOption({
    required this.label,
    required this.value,
    required this.groupValue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return RadioListTile<String>(
      value:      value,
      groupValue: groupValue,
      onChanged:  onChanged,
      title:      Text(label),
      activeColor: AppColors.primary,
      contentPadding: EdgeInsets.zero,
    );
  }
}