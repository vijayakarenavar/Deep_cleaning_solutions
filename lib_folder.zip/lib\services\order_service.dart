// lib/services/order_service.dart

import 'api_client.dart';

class OrderService {
  final ApiClient _api = ApiClient();

  // ── Get All Orders ────────────────────────────────────────────────
  // ✅ API doc: GET /orders
  Future<Map<String, dynamic>> getOrders({
    String? status,
    int page = 1,
  }) async {
    final response = await _api.get(
      '/orders',
      queryParams: {
        if (status != null) 'status': status,
        'page': page,
      },
    );
    return response.data;
  }

  // ── Get Order Detail ──────────────────────────────────────────────
  // ✅ API doc: GET /orders/{orderId}
  Future<Map<String, dynamic>> getOrderDetail(int orderId) async {
    final response = await _api.get('/orders/$orderId');
    return response.data;
  }

  // ── Get Payment Status ────────────────────────────────────────────
  // ✅ API doc: GET /orders/{orderId}/payment-status
  Future<Map<String, dynamic>> getPaymentStatus(int orderId) async {
    final response = await _api.get('/orders/$orderId/payment-status');
    return response.data;
  }

  // ── Checkout Init ─────────────────────────────────────────────────
  // ✅ API doc: GET /checkout/init
  Future<Map<String, dynamic>> checkoutInit() async {
    final response = await _api.get('/checkout/init');
    return response.data;
  }

  // ── Get Time Slots ────────────────────────────────────────────────
  // ✅ API doc: POST /checkout/time-slots
  Future<Map<String, dynamic>> getTimeSlots({
    required String date,
    required String serviceType,
  }) async {
    final response = await _api.post(
      '/checkout/time-slots',
      data: {
        'date':         date,
        'service_type': serviceType,
      },
    );
    return response.data;
  }

  // ── Checkout Summary ──────────────────────────────────────────────
  // ✅ API doc: POST /checkout/summary
  Future<Map<String, dynamic>> checkoutSummary({
    required String address,
    required String city,
    required String state,
    required String date,
    required String time,
  }) async {
    final response = await _api.post(
      '/checkout/summary',
      data: {
        'address': address,
        'city':    city,
        'state':   state,
        'date':    date,
        'time':    time,
      },
    );
    return response.data;
  }

  // ── Process Full Payment ──────────────────────────────────────────
  // ✅ API doc: POST /checkout/process
  Future<Map<String, dynamic>> processOrder({
    required String address,
    required String city,
    required String state,
    required String date,
    required String time,
    required String paymentMethod,
  }) async {
    final response = await _api.post(
      '/checkout/process',
      data: {
        'address':        address,
        'city':           city,
        'state':          state,
        'date':           date,
        'time':           time,
        'payment_method': paymentMethod,
      },
    );
    return response.data;
  }

  // ── Process Advance Payment ───────────────────────────────────────
  // ✅ API doc: POST /checkout/process-advance
  Future<Map<String, dynamic>> processAdvanceOrder({
    required String address,
    required String city,
    required String state,
    required String date,
    required String time,
    required String paymentMethod,
  }) async {
    final response = await _api.post(
      '/checkout/process-advance',
      data: {
        'address':        address,
        'city':           city,
        'state':          state,
        'date':           date,
        'time':           time,
        'payment_method': paymentMethod,
      },
    );
    return response.data;
  }
}