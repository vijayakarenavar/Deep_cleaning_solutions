// lib/providers/order_provider.dart

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/order_service.dart';

class OrderState {
  final bool isLoading;
  final List<dynamic> orders;
  final Map<String, dynamic>? selectedOrder;
  final List<dynamic> timeSlots;
  final String? error;

  const OrderState({
    this.isLoading     = false,
    this.orders        = const [],
    this.selectedOrder,
    this.timeSlots     = const [],
    this.error,
  });

  OrderState copyWith({
    bool? isLoading,
    List<dynamic>? orders,
    Map<String, dynamic>? selectedOrder,
    List<dynamic>? timeSlots,
    String? error,
  }) {
    return OrderState(
      isLoading:     isLoading     ?? this.isLoading,
      orders:        orders        ?? this.orders,
      selectedOrder: selectedOrder ?? this.selectedOrder,
      timeSlots:     timeSlots     ?? this.timeSlots,
      error:         error         ?? this.error,
    );
  }
}

class OrderNotifier extends StateNotifier<OrderState> {
  final OrderService _orderService = OrderService();
  OrderNotifier() : super(const OrderState());

  // ── Get All Orders ─────────────────────────────────────────────────
  // ✅ API doc: GET /orders
  Future<void> getOrders({String? status, int page = 1}) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final response = await _orderService.getOrders(status: status, page: page);
      state = state.copyWith(
        isLoading: false,
        orders:    (response['data']?['orders']) ?? [],
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  // ── Get Order Detail ───────────────────────────────────────────────
  // ✅ API doc: GET /orders/{orderId}
  Future<void> getOrderDetail(int orderId) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final response = await _orderService.getOrderDetail(orderId);
      state = state.copyWith(
        isLoading:     false,
        selectedOrder: response['data'],
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  // ── Get Payment Status ─────────────────────────────────────────────
  // ✅ API doc: GET /orders/{orderId}/payment-status
  Future<Map<String, dynamic>?> getPaymentStatus(int orderId) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final response = await _orderService.getPaymentStatus(orderId);
      state = state.copyWith(isLoading: false);
      return response['data'];
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
      return null;
    }
  }

  // ── Get Time Slots ─────────────────────────────────────────────────
  // ✅ API doc: POST /checkout/time-slots
  Future<void> getTimeSlots({
    required String date,
    required String serviceType,
  }) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final response = await _orderService.getTimeSlots(
        date:        date,
        serviceType: serviceType,
      );
      state = state.copyWith(
        isLoading: false,
        timeSlots: response['data']?['time_slots'] ?? [],
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  // ── Process Order (COD) ────────────────────────────────────────────
  // ✅ API doc: POST /checkout/process
  Future<bool> processOrder({
    required String address,
    required String city,
    required String state_,
    required String date,
    required String time,
  }) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final response = await _orderService.processOrder(
        address:       address,
        city:          city,
        state:         state_,
        date:          date,
        time:          time,
        paymentMethod: 'cod',
      );
      state = state.copyWith(
        isLoading:     false,
        selectedOrder: response['data'],
      );
      await getOrders();
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
      return false;
    }
  }

  // ── Process Advance Order (Online) ─────────────────────────────────
  // ✅ API doc: POST /checkout/process-advance
  Future<bool> processAdvanceOrder({
    required String address,
    required String city,
    required String state_,
    required String date,
    required String time,
  }) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final response = await _orderService.processAdvanceOrder(
        address:       address,
        city:          city,
        state:         state_,
        date:          date,
        time:          time,
        paymentMethod: 'razorpay',
      );
      state = state.copyWith(
        isLoading:     false,
        selectedOrder: response['data'],
      );
      await getOrders();
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
      return false;
    }
  }

  // ── Add Order (checkout screen साठी) ──────────────────────────────
  void addOrder(Map<String, dynamic> order) {
    final updated = [...state.orders];
    updated.insert(0, order);
    state = state.copyWith(orders: updated);
  }

  void clearSelectedOrder() => state = state.copyWith(selectedOrder: null);
  void clearError()         => state = state.copyWith(error: null);
}

final orderProvider = StateNotifierProvider<OrderNotifier, OrderState>(
      (ref) => OrderNotifier(),
);