// lib/services/cart_service.dart

import 'api_client.dart';

class CartService {
  final ApiClient _api = ApiClient();

  Future<Map<String, dynamic>> getCart() async {
    final response = await _api.get('/cart');
    final data = response.data['data'] ?? {};
    return {
      'cart_items':   data['items']    ?? [],
      'cart_count':   data['count']    ?? 0,
      'total_amount': double.tryParse(data['subtotal']?.toString() ?? '0') ?? 0.0,
      'discount':     double.tryParse(data['discount']?.toString() ?? '0') ?? 0.0,
      'final_amount': double.tryParse(data['final_amount']?.toString() ?? data['subtotal']?.toString() ?? '0') ?? 0.0,
      'coupon_code':  data['coupon_code'],
    };
  }

  Future<Map<String, dynamic>> addToCart({
    required int productId,
    required int quantity,
    Map<String, dynamic>? extras,
  }) async {
    final response = await _api.post(
      '/cart/add',
      data: {
        'product_id': productId,
        'quantity':   quantity,
        if (extras != null) ...extras,
      },
    );
    return response.data;
  }

  Future<Map<String, dynamic>> addFlatToCart({
    required int productId,
    required String slug,
    required String bhkType,
    required String flatType,
    required double sqft,
    bool cleanWalls  = false,
    bool cleanPaint  = false,
    bool removeCover = false,
  }) async {
    final data = {
      'product_id':   productId,
      'slug':         slug,
      'quantity':     1,
      'bhk_type':     bhkType,
      'flat_type':    flatType,
      'sqft':         sqft,
      'clean_walls':  cleanWalls,
      'clean_paint':  cleanPaint,
      'remove_cover': removeCover,
    };
    final response = await _api.post('/cart/add-flat', data: data);
    return response.data;
  }

  // ✅ String type — row_id साठी
  Future<Map<String, dynamic>> updateCartItem({
    required String cartItemId,
    required int quantity,
  }) async {
    final response = await _api.put(
      '/cart/update',
      data: {
        'row_id':   cartItemId,
        'quantity': quantity,
      },
    );
    return response.data;
  }

  // ✅ String type — row_id साठी
  Future<Map<String, dynamic>> removeCartItem(String cartItemId) async {
    final response = await _api.delete(
      '/cart/item',
      data: {'row_id': cartItemId},
    );
    return response.data;
  }

  Future<Map<String, dynamic>> applyCoupon(String couponCode) async {
    final response = await _api.post(
      '/checkout/apply-coupon',
      data: {'coupon_code': couponCode},
    );
    return response.data;
  }

  Future<Map<String, dynamic>> removeCoupon() async {
    final response = await _api.post('/checkout/remove-coupon', data: {});
    return response.data;
  }

  Future<Map<String, dynamic>> getCartRowId({
    required int productId,
  }) async {
    final response = await _api.post(
      '/cart/row-id',
      data: {'product_id': productId},
    );
    return response.data;
  }
}